import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Package, ArrowLeft } from "lucide-react";

export default function Orders() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  const { data: orders, isLoading } = trpc.orders.list.useQuery();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background py-8">
        <div className="container">
          <div className="skeleton h-96" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container">
        <div className="mb-8 flex items-center gap-4">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-5 w-5" />
            Voltar
          </button>
        </div>

        <h1 className="mb-8 text-3xl font-bold">Meus Pedidos</h1>

        {!orders || orders.length === 0 ? (
          <div className="flex-center min-h-96 flex-col gap-4">
            <Package className="h-16 w-16 text-muted-foreground" />
            <h2 className="text-xl font-semibold">Nenhum pedido encontrado</h2>
            <p className="text-muted-foreground">
              Você ainda não fez nenhuma compra
            </p>
            <Button onClick={() => navigate("/")} className="btn-primary mt-4">
              Explorar Produtos
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => (
              <div
                key={order.id}
                className="rounded-xl border border-border bg-card p-6 animate-slideInUp hover:shadow-lg transition-all"
              >
                <div className="mb-4 flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold">Pedido #{order.orderNumber}</h3>
                    <p className="text-sm text-muted-foreground">
                      {new Date(order.createdAt).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                  <span
                    className={`inline-block rounded-full px-3 py-1 text-sm font-semibold ${
                      order.status === "delivered"
                        ? "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400"
                        : order.status === "cancelled"
                        ? "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-400"
                        : "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-400"
                    }`}
                  >
                    {order.status === "pending" && "Pendente"}
                    {order.status === "confirmed" && "Confirmado"}
                    {order.status === "processing" && "Processando"}
                    {order.status === "shipped" && "Enviado"}
                    {order.status === "delivered" && "Entregue"}
                    {order.status === "cancelled" && "Cancelado"}
                  </span>
                </div>

                <div className="mb-4 grid gap-4 md:grid-cols-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Total</p>
                    <p className="font-semibold">
                      R$ {parseFloat(order.totalPrice).toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Endereço</p>
                    <p className="text-sm">{order.shippingCity}, {order.shippingState}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Pagamento</p>
                    <p className="text-sm">
                      {order.paymentStatus === "completed"
                        ? "✓ Pago"
                        : "Aguardando"}
                    </p>
                  </div>
                  <div className="flex items-end">
                    <Button className="btn-secondary text-sm">
                      Ver Detalhes
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

