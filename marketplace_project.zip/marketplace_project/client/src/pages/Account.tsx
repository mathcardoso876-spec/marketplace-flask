import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { ArrowLeft, LogOut } from "lucide-react";

export default function Account() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container max-w-2xl">
        <div className="mb-8 flex items-center gap-4">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-5 w-5" />
            Voltar
          </button>
        </div>

        <h1 className="mb-8 text-3xl font-bold">Minha Conta</h1>

        <div className="rounded-xl border border-border bg-card p-8 animate-slideInUp">
          <div className="mb-8">
            <h2 className="mb-6 text-xl font-bold">Informações Pessoais</h2>

            <div className="space-y-4">
              <div>
                <label className="mb-2 block text-sm font-semibold">Nome</label>
                <Input
                  value={user?.name || ""}
                  disabled
                  className="bg-muted"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold">Email</label>
                <Input
                  value={user?.email || ""}
                  disabled
                  className="bg-muted"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold">Telefone</label>
                <Input
                  value={user?.phone || ""}
                  disabled
                  className="bg-muted"
                />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="mb-2 block text-sm font-semibold">Cidade</label>
                  <Input
                    value={user?.city || ""}
                    disabled
                    className="bg-muted"
                  />
                </div>
                <div>
                  <label className="mb-2 block text-sm font-semibold">Estado</label>
                  <Input
                    value={user?.state || ""}
                    disabled
                    className="bg-muted"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-border pt-8">
            <h2 className="mb-6 text-xl font-bold">Ações</h2>

            <div className="space-y-3">
              <Button onClick={() => navigate("/orders")} className="w-full btn-secondary">
                Ver Meus Pedidos
              </Button>

              <Button
                onClick={handleLogout}
                className="w-full btn-ghost"
              >
                <LogOut className="mr-2 h-5 w-5" />
                Sair da Conta
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

