import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { useState } from "react";
import { Plus, Trash2, Edit2, ArrowLeft } from "lucide-react";

export default function AdminDashboard() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    originalPrice: "",
    category: "Eletrônicos",
    stock: "0",
    image: "",
  });

  const { data: products, refetch } = trpc.products.list.useQuery({
    limit: 100,
  });

  const createProductMutation = trpc.products.create.useMutation({
    onSuccess: () => {
      alert("Produto criado com sucesso!");
      resetForm();
      refetch();
    },
  });

  const updateProductMutation = trpc.products.update.useMutation({
    onSuccess: () => {
      alert("Produto atualizado com sucesso!");
      resetForm();
      refetch();
    },
  });

  const deleteProductMutation = trpc.products.delete.useMutation({
    onSuccess: () => {
      alert("Produto deletado com sucesso!");
      refetch();
    },
  });

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Acesso Negado</h1>
          <p className="text-muted-foreground mb-4">
            Você não tem permissão para acessar este painel
          </p>
          <Button onClick={() => navigate("/")} className="btn-primary">
            Voltar para Home
          </Button>
        </div>
      </div>
    );
  }

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      price: "",
      originalPrice: "",
      category: "Eletrônicos",
      stock: "0",
      image: "",
    });
    setEditingId(null);
    setShowForm(false);
  };

  const handleSubmit = () => {
    if (!formData.name || !formData.price || !formData.category) {
      alert("Por favor, preencha os campos obrigatórios");
      return;
    }

    if (editingId) {
      updateProductMutation.mutate({
        id: editingId,
        ...formData,
        stock: parseInt(formData.stock),
      });
    } else {
      createProductMutation.mutate({
        ...formData,
        stock: parseInt(formData.stock),
      });
    }
  };

  const handleEdit = (product: any) => {
    setFormData({
      name: product.name,
      description: product.description || "",
      price: product.price,
      originalPrice: product.originalPrice || "",
      category: product.category,
      stock: product.stock.toString(),
      image: product.image || "",
    });
    setEditingId(product.id);
    setShowForm(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Tem certeza que deseja deletar este produto?")) {
      deleteProductMutation.mutate({ id });
    }
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container">
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/")}
              className="flex items-center gap-2 text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <h1 className="text-3xl font-bold">Painel Administrativo</h1>
          </div>
          <Button
            onClick={() => setShowForm(true)}
            className="btn-primary"
          >
            <Plus className="mr-2 h-5 w-5" />
            Novo Produto
          </Button>
        </div>

        {/* Product Form */}
        {showForm && (
          <div className="mb-8 rounded-xl border border-border bg-card p-8 animate-slideInUp">
            <h2 className="mb-6 text-2xl font-bold">
              {editingId ? "Editar Produto" : "Novo Produto"}
            </h2>

            <div className="space-y-4">
              <div>
                <label className="mb-2 block text-sm font-semibold">Nome *</label>
                <Input
                  placeholder="Nome do produto"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold">
                  Descrição
                </label>
                <Textarea
                  placeholder="Descrição do produto"
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  className="min-h-24"
                />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="mb-2 block text-sm font-semibold">
                    Preço *
                  </label>
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={formData.price}
                    onChange={(e) =>
                      setFormData({ ...formData, price: e.target.value })
                    }
                  />
                </div>
                <div>
                  <label className="mb-2 block text-sm font-semibold">
                    Preço Original
                  </label>
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={formData.originalPrice}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        originalPrice: e.target.value,
                      })
                    }
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="mb-2 block text-sm font-semibold">
                    Categoria *
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) =>
                      setFormData({ ...formData, category: e.target.value })
                    }
                    className="w-full rounded-lg border border-border bg-background px-3 py-2"
                  >
                    <option>Eletrônicos</option>
                    <option>Moda</option>
                    <option>Casa</option>
                    <option>Esportes</option>
                    <option>Beleza</option>
                    <option>Livros</option>
                  </select>
                </div>
                <div>
                  <label className="mb-2 block text-sm font-semibold">
                    Estoque
                  </label>
                  <Input
                    type="number"
                    placeholder="0"
                    value={formData.stock}
                    onChange={(e) =>
                      setFormData({ ...formData, stock: e.target.value })
                    }
                  />
                </div>
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold">
                  URL da Imagem
                </label>
                <Input
                  placeholder="https://..."
                  value={formData.image}
                  onChange={(e) =>
                    setFormData({ ...formData, image: e.target.value })
                  }
                />
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={handleSubmit}
                  disabled={
                    createProductMutation.isPending ||
                    updateProductMutation.isPending
                  }
                  className="btn-primary"
                >
                  {editingId ? "Atualizar" : "Criar"} Produto
                </Button>
                <Button onClick={resetForm} className="btn-ghost">
                  Cancelar
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Products List */}
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-border bg-muted">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold">
                    Nome
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">
                    Categoria
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">
                    Preço
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">
                    Estoque
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody>
                {products?.map((product) => (
                  <tr
                    key={product.id}
                    className="border-b border-border hover:bg-muted/50 transition-colors"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        {product.image && (
                          <img
                            src={product.image}
                            alt={product.name}
                            className="h-10 w-10 rounded object-cover"
                          />
                        )}
                        <span className="font-medium">{product.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      {product.category}
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold">
                      R$ {parseFloat(product.price).toFixed(2)}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <span
                        className={`inline-block rounded-full px-3 py-1 text-xs font-semibold ${
                          product.stock > 0
                            ? "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400"
                            : "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-400"
                        }`}
                      >
                        {product.stock}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEdit(product)}
                          className="rounded-lg p-2 hover:bg-muted"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(product.id)}
                          className="rounded-lg p-2 hover:bg-red-100 dark:hover:bg-red-950"
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

