import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Link } from "wouter";
import { ShoppingCart, Search, Star, Truck, Shield, Zap } from "lucide-react";
import ProductCarousel from "@/components/ProductCarousel";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>();

  const { data: products, isLoading } = trpc.products.list.useQuery({
    limit: 12,
    offset: 0,
    category: selectedCategory,
    search: searchQuery || undefined,
  });

  const categories = [
    "Eletrônicos",
    "Moda",
    "Casa",
    "Esportes",
    "Beleza",
    "Livros",
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur">
        <div className="container flex items-center justify-between py-4">
          <Link href="/">
            <a className="flex items-center gap-2">
              {APP_LOGO && (
                <img src={APP_LOGO} alt={APP_TITLE} className="h-8 w-8" />
              )}
              <span className="text-xl font-bold text-gradient">{APP_TITLE}</span>
            </a>
          </Link>

          <div className="hidden flex-1 items-center gap-4 px-8 md:flex">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Buscar produtos..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Link href="/cart">
                  <a className="relative flex items-center gap-2 rounded-lg p-2 hover:bg-muted">
                    <ShoppingCart className="h-5 w-5" />
                    <span className="hidden sm:inline text-sm">Carrinho</span>
                  </a>
                </Link>
                <Link href="/account">
                  <a className="rounded-lg px-4 py-2 text-sm font-medium hover:bg-muted">
                    {user?.name || "Conta"}
                  </a>
                </Link>
                {user?.role === "admin" && (
                  <Link href="/admin">
                    <a className="btn-primary text-sm">Painel Admin</a>
                  </Link>
                )}
              </>
            ) : (
              <a href={getLoginUrl()} className="btn-primary text-sm">
                Entrar
              </a>
            )}
          </div>
        </div>

        {/* Mobile Search */}
        <div className="border-t border-border px-4 py-3 md:hidden">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Buscar..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </header>

      {/* Carousel Section */}
      <section className="py-8 md:py-12">
        <div className="container">
          {products && products.length > 0 && (
            <ProductCarousel
              products={products.slice(0, 8).map((p) => ({
                id: p.id,
                name: p.name,
                image: p.image || "https://via.placeholder.com/400",
                price: p.price,
                originalPrice: p.originalPrice,
                rating: p.rating || "0",
                reviewCount: p.reviewCount || 0,
                category: p.category,
              }))}
              autoPlayInterval={6000}
            />
          )}
        </div>
      </section>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-orange-500 via-red-500 to-pink-500 py-16 md:py-24">
        <div className="container relative z-10">
          <div className="max-w-2xl animate-slideInUp">
            <h1 className="mb-4 text-4xl font-bold text-white md:text-5xl">
              Explore Nossos Produtos
            </h1>
            <p className="mb-8 text-lg text-white/90">
              Encontre as melhores ofertas em eletrônicos, moda, casa, esportes e muito mais!
            </p>
            <div className="flex flex-col gap-4 sm:flex-row">
              <Button className="btn-primary">
                Começar a Comprar
              </Button>
              {!isAuthenticated && (
                <a href={getLoginUrl()} className="btn-secondary">
                  Criar Conta
                </a>
              )}
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute right-0 top-0 h-96 w-96 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -bottom-20 left-1/4 h-96 w-96 rounded-full bg-white/10 blur-3xl" />
      </section>

      {/* Features */}
      <section className="border-b border-border bg-card py-12">
        <div className="container">
          <div className="grid gap-8 md:grid-cols-3">
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 rounded-full bg-orange-100 p-4 dark:bg-orange-950">
                <Truck className="h-6 w-6 text-orange-500" />
              </div>
              <h3 className="mb-2 font-semibold">Entrega Rápida</h3>
              <p className="text-sm text-muted-foreground">
                Receba seus pedidos em até 7 dias úteis
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 rounded-full bg-orange-100 p-4 dark:bg-orange-950">
                <Shield className="h-6 w-6 text-orange-500" />
              </div>
              <h3 className="mb-2 font-semibold">Compra Segura</h3>
              <p className="text-sm text-muted-foreground">
                Proteção total em todas as transações
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 rounded-full bg-orange-100 p-4 dark:bg-orange-950">
                <Zap className="h-6 w-6 text-orange-500" />
              </div>
              <h3 className="mb-2 font-semibold">Melhor Preço</h3>
              <p className="text-sm text-muted-foreground">
                Garantia do melhor preço do mercado
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="border-b border-border py-8">
        <div className="container">
          <h2 className="mb-6 text-2xl font-bold">Categorias</h2>
          <div className="flex gap-3 overflow-x-auto pb-2">
            <button
              onClick={() => setSelectedCategory(undefined)}
              className={`whitespace-nowrap rounded-full px-6 py-2 font-medium transition-all ${
                !selectedCategory
                  ? "bg-orange-500 text-white"
                  : "border border-border hover:border-orange-500"
              }`}
            >
              Todos
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`whitespace-nowrap rounded-full px-6 py-2 font-medium transition-all ${
                  selectedCategory === cat
                    ? "bg-orange-500 text-white"
                    : "border border-border hover:border-orange-500"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-12">
        <div className="container">
          <h2 className="mb-8 text-2xl font-bold">Produtos em Destaque</h2>

          {isLoading ? (
            <div className="grid gap-6 grid-auto-fit">
              {Array.from({ length: 12 }).map((_, i) => (
                <div
                  key={i}
                  className="product-card h-80 skeleton"
                />
              ))}
            </div>
          ) : products && products.length > 0 ? (
            <div className="grid gap-6 grid-auto-fit">
              {products.map((product) => (
                <Link key={product.id} href={`/product/${product.id}`}>
                  <a className="product-card group animate-slideInUp">
                    <div className="relative mb-4 overflow-hidden rounded-lg bg-muted">
                      <img
                        src={product.image || "https://via.placeholder.com/200"}
                        alt={product.name}
                        className="h-48 w-full object-cover transition-transform duration-300 group-hover:scale-110"
                      />
                      {product.originalPrice && (
                        <div className="absolute right-2 top-2 rounded-lg bg-red-500 px-2 py-1 text-xs font-bold text-white">
                          -{Math.round(((parseFloat(product.originalPrice) - parseFloat(product.price)) / parseFloat(product.originalPrice)) * 100)}%
                        </div>
                      )}
                    </div>

                    <h3 className="mb-2 line-clamp-2 font-semibold">
                      {product.name}
                    </h3>

                    <div className="mb-3 flex items-center gap-1">
                      <div className="flex items-center gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < Math.round(parseFloat(product.rating || "0"))
                                ? "fill-yellow-400 text-yellow-400"
                                : "text-muted-foreground"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        ({product.reviewCount})
                      </span>
                    </div>

                    <div className="mb-4 flex items-baseline gap-2">
                      <span className="text-xl font-bold text-orange-500">
                        R$ {parseFloat(product.price).toFixed(2)}
                      </span>
                      {product.originalPrice && (
                        <span className="text-sm line-through text-muted-foreground">
                          R$ {parseFloat(product.originalPrice).toFixed(2)}
                        </span>
                      )}
                    </div>

                    <Button className="w-full btn-primary">
                      <ShoppingCart className="mr-2 h-4 w-4" />
                      Adicionar ao Carrinho
                    </Button>
                  </a>
                </Link>
              ))}
            </div>
          ) : (
            <div className="flex-center py-12">
              <div className="text-center">
                <p className="text-lg text-muted-foreground">
                  Nenhum produto encontrado
                </p>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card py-12">
        <div className="container">
          <div className="grid gap-8 md:grid-cols-4">
            <div>
              <h4 className="mb-4 font-semibold">Sobre</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Quem Somos</a></li>
                <li><a href="#" className="hover:text-foreground">Carreiras</a></li>
                <li><a href="#" className="hover:text-foreground">Blog</a></li>
              </ul>
            </div>
            <div>
              <h4 className="mb-4 font-semibold">Suporte</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Central de Ajuda</a></li>
                <li><a href="#" className="hover:text-foreground">Contato</a></li>
                <li><a href="#" className="hover:text-foreground">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4 className="mb-4 font-semibold">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Privacidade</a></li>
                <li><a href="#" className="hover:text-foreground">Termos</a></li>
                <li><a href="#" className="hover:text-foreground">Cookies</a></li>
              </ul>
            </div>
            <div>
              <h4 className="mb-4 font-semibold">Redes Sociais</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Facebook</a></li>
                <li><a href="#" className="hover:text-foreground">Instagram</a></li>
                <li><a href="#" className="hover:text-foreground">Twitter</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 {APP_TITLE}. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

