import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useRoute, useLocation } from "wouter";
import { useState } from "react";
import { ShoppingCart, Star, Truck, Shield, Heart } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";

export default function ProductDetail() {
  const [, params] = useRoute("/product/:id");
  const [, navigate] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState("");

  const productId = params?.id ? parseInt(params.id) : 0;

  const { data: product, isLoading } = trpc.products.getById.useQuery(
    { id: productId },
    { enabled: !!productId }
  );

  const { data: reviews } = trpc.reviews.getByProduct.useQuery(
    { productId },
    { enabled: !!productId }
  );

  const addToCartMutation = trpc.cart.add.useMutation({
    onSuccess: () => {
      alert("Produto adicionado ao carrinho!");
      setQuantity(1);
    },
  });

  const createReviewMutation = trpc.reviews.create.useMutation({
    onSuccess: () => {
      alert("Avaliação enviada com sucesso!");
      setShowReviewForm(false);
      setReviewComment("");
      setReviewRating(5);
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background py-8">
        <div className="container">
          <div className="skeleton h-96" />
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Produto não encontrado</h1>
          <Button onClick={() => navigate("/")} className="btn-primary">
            Voltar para Home
          </Button>
        </div>
      </div>
    );
  }

  const images = product.images
    ? JSON.parse(product.images)
    : [product.image || "https://via.placeholder.com/400"];

  const handleAddToCart = () => {
    if (!isAuthenticated) {
      alert("Faça login para adicionar ao carrinho");
      return;
    }
    addToCartMutation.mutate({ productId, quantity });
  };

  const handleSubmitReview = () => {
    if (!isAuthenticated) {
      alert("Faça login para deixar uma avaliação");
      return;
    }
    createReviewMutation.mutate({
      productId,
      rating: reviewRating,
      comment: reviewComment,
      title: "Avaliação",
    });
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container">
        {/* Product Section */}
        <div className="mb-12 grid gap-8 md:grid-cols-2">
          {/* Images */}
          <div className="animate-slideInLeft">
            <div className="mb-4 overflow-hidden rounded-xl bg-muted">
              <img
                src={images[selectedImage] || "https://via.placeholder.com/400"}
                alt={product.name}
                className="h-96 w-full object-cover"
              />
            </div>
            {images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto">
                {images.map((img: string, idx: number) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`h-20 w-20 rounded-lg border-2 overflow-hidden transition-all ${
                      selectedImage === idx
                        ? "border-orange-500"
                        : "border-border"
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.name} ${idx + 1}`}
                      className="h-full w-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="animate-slideInRight">
            <div className="mb-4">
              <span className="inline-block rounded-full bg-orange-100 px-3 py-1 text-sm font-semibold text-orange-600 dark:bg-orange-950 dark:text-orange-400">
                {product.category}
              </span>
            </div>

            <h1 className="mb-4 text-3xl font-bold">{product.name}</h1>

            {/* Rating */}
            <div className="mb-6 flex items-center gap-4">
              <div className="flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.round(parseFloat(product.rating || "0"))
                        ? "fill-yellow-400 text-yellow-400"
                        : "text-muted-foreground"
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-muted-foreground">
                {product.reviewCount} avaliações
              </span>
            </div>

            {/* Price */}
            <div className="mb-6">
              <div className="flex items-baseline gap-3">
                <span className="text-4xl font-bold text-orange-500">
                  R$ {parseFloat(product.price).toFixed(2)}
                </span>
                {product.originalPrice && (
                  <span className="text-lg line-through text-muted-foreground">
                    R$ {parseFloat(product.originalPrice).toFixed(2)}
                  </span>
                )}
              </div>
              {product.originalPrice && (
                <p className="mt-2 text-sm text-green-600">
                  Economize R$ {(parseFloat(product.originalPrice) - parseFloat(product.price)).toFixed(2)}
                </p>
              )}
            </div>

            {/* Description */}
            <div className="mb-6">
              <h3 className="mb-2 font-semibold">Descrição</h3>
              <p className="text-muted-foreground">{product.description}</p>
            </div>

            {/* Stock */}
            <div className="mb-6">
              <p className="text-sm">
                <span className="font-semibold">Estoque:</span>{" "}
                <span className={product.stock > 0 ? "text-green-600" : "text-red-600"}>
                  {product.stock > 0 ? `${product.stock} disponíveis` : "Fora de estoque"}
                </span>
              </p>
            </div>

            {/* Quantity Selector */}
            <div className="mb-6 flex items-center gap-4">
              <span className="font-semibold">Quantidade:</span>
              <div className="flex items-center gap-2 border border-border rounded-lg">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-2 hover:bg-muted"
                >
                  −
                </button>
                <span className="w-8 text-center">{quantity}</span>
                <button
                  onClick={() =>
                    setQuantity(Math.min(product.stock, quantity + 1))
                  }
                  className="px-3 py-2 hover:bg-muted"
                >
                  +
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mb-6 flex gap-4">
              <Button
                onClick={handleAddToCart}
                disabled={product.stock === 0 || addToCartMutation.isPending}
                className="flex-1 btn-primary"
              >
                <ShoppingCart className="mr-2 h-5 w-5" />
                {addToCartMutation.isPending
                  ? "Adicionando..."
                  : "Adicionar ao Carrinho"}
              </Button>
              <Button className="btn-secondary">
                <Heart className="h-5 w-5" />
              </Button>
            </div>

            {/* Features */}
            <div className="space-y-3 border-t border-border pt-6">
              <div className="flex items-center gap-3">
                <Truck className="h-5 w-5 text-orange-500" />
                <span className="text-sm">Entrega rápida em todo Brasil</span>
              </div>
              <div className="flex items-center gap-3">
                <Shield className="h-5 w-5 text-orange-500" />
                <span className="text-sm">Compra 100% segura e protegida</span>
              </div>
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="border-t border-border pt-8">
          <h2 className="mb-8 text-2xl font-bold">Avaliações</h2>

          {/* Review Form */}
          {isAuthenticated && (
            <div className="mb-8 rounded-xl border border-border bg-card p-6">
              {!showReviewForm ? (
                <Button
                  onClick={() => setShowReviewForm(true)}
                  className="btn-primary"
                >
                  Deixar uma Avaliação
                </Button>
              ) : (
                <div className="space-y-4">
                  <div>
                    <label className="mb-2 block font-semibold">Nota</label>
                    <div className="flex gap-2">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <button
                          key={i}
                          onClick={() => setReviewRating(i + 1)}
                          className="transition-transform hover:scale-110"
                        >
                          <Star
                            className={`h-8 w-8 ${
                              i < reviewRating
                                ? "fill-yellow-400 text-yellow-400"
                                : "text-muted-foreground"
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="mb-2 block font-semibold">Comentário</label>
                    <Textarea
                      placeholder="Compartilhe sua experiência com este produto..."
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      className="min-h-24"
                    />
                  </div>

                  <div className="flex gap-3">
                    <Button
                      onClick={handleSubmitReview}
                      disabled={createReviewMutation.isPending}
                      className="btn-primary"
                    >
                      {createReviewMutation.isPending
                        ? "Enviando..."
                        : "Enviar Avaliação"}
                    </Button>
                    <Button
                      onClick={() => setShowReviewForm(false)}
                      className="btn-ghost"
                    >
                      Cancelar
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Reviews List */}
          <div className="space-y-4">
            {reviews && reviews.length > 0 ? (
              reviews.map((review) => (
                <div
                  key={review.id}
                  className="rounded-xl border border-border bg-card p-6 animate-slideInUp"
                >
                  <div className="mb-3 flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < review.rating
                                ? "fill-yellow-400 text-yellow-400"
                                : "text-muted-foreground"
                            }`}
                          />
                        ))}
                      </div>
                      {review.isVerifiedPurchase && (
                        <span className="mt-1 inline-block rounded-full bg-green-100 px-2 py-1 text-xs font-semibold text-green-700 dark:bg-green-950 dark:text-green-400">
                          Compra Verificada
                        </span>
                      )}
                    </div>
                  </div>
                  {review.title && (
                    <h4 className="mb-2 font-semibold">{review.title}</h4>
                  )}
                  <p className="mb-3 text-muted-foreground">{review.comment}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(review.createdAt).toLocaleDateString("pt-BR")}
                  </p>
                </div>
              ))
            ) : (
              <div className="flex-center py-12">
                <p className="text-muted-foreground">
                  Nenhuma avaliação ainda. Seja o primeiro a avaliar!
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

