import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { useState } from "react";
import { Trash2, ArrowLeft, ShoppingCart } from "lucide-react";

export default function Cart() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [showCheckout, setShowCheckout] = useState(false);
  const [formData, setFormData] = useState({
    shippingAddress: "",
    shippingCity: "",
    shippingState: "",
    shippingZipCode: "",
    shippingCountry: "Brasil",
  });

  const { data: cartItems, refetch } = trpc.cart.list.useQuery();

  const removeFromCartMutation = trpc.cart.remove.useMutation({
    onSuccess: () => refetch(),
  });

  const updateQuantityMutation = trpc.cart.updateQuantity.useMutation({
    onSuccess: () => refetch(),
  });

  const createOrderMutation = trpc.orders.create.useMutation({
    onSuccess: (data) => {
      alert(`Pedido criado com sucesso! Número: ${data.orderNumber}`);
      navigate(`/order/${data.orderNumber}`);
    },
  });

  const handleRemove = (cartItemId: number) => {
    removeFromCartMutation.mutate({ cartItemId });
  };

  const handleUpdateQuantity = (cartItemId: number, quantity: number) => {
    updateQuantityMutation.mutate({ cartItemId, quantity });
  };

  const handleCheckout = () => {
    if (
      !formData.shippingAddress ||
      !formData.shippingCity ||
      !formData.shippingState ||
      !formData.shippingZipCode
    ) {
      alert("Por favor, preencha todos os campos de endereço");
      return;
    }

    createOrderMutation.mutate({
      totalPrice: totalPrice.toString(),
      shippingAddress: formData.shippingAddress,
      shippingCity: formData.shippingCity,
      shippingState: formData.shippingState,
      shippingZipCode: formData.shippingZipCode,
      shippingCountry: formData.shippingCountry,
      paymentMethod: "credit_card",
    });
  };

  if (!cartItems) {
    return (
      <div className="min-h-screen bg-background py-8">
        <div className="container">
          <div className="skeleton h-96" />
        </div>
      </div>
    );
  }

  const totalPrice = cartItems.reduce(
    (sum, item) => sum + parseFloat(item.product?.price || "0") * item.quantity,
    0
  );

  const subtotal = totalPrice;
  const shipping = subtotal > 100 ? 0 : 15;
  const total = subtotal + shipping;

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container">
        {/* Header */}
        <div className="mb-8 flex items-center gap-4">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-5 w-5" />
            Continuar Comprando
          </button>
        </div>

        <h1 className="mb-8 text-3xl font-bold">Carrinho de Compras</h1>

        {cartItems.length === 0 ? (
          <div className="flex-center min-h-96 flex-col gap-4">
            <ShoppingCart className="h-16 w-16 text-muted-foreground" />
            <h2 className="text-xl font-semibold">Seu carrinho está vazio</h2>
            <p className="text-muted-foreground">
              Adicione produtos para começar a comprar
            </p>
            <Button onClick={() => navigate("/")} className="btn-primary mt-4">
              Explorar Produtos
            </Button>
          </div>
        ) : (
          <div className="grid gap-8 lg:grid-cols-3">
            {/* Cart Items */}
            <div className="lg:col-span-2">
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <div
                    key={item.id}
                    className="flex gap-4 rounded-xl border border-border bg-card p-4 animate-slideInUp"
                  >
                    <img
                      src={item.product?.image || "https://via.placeholder.com/100"}
                      alt={item.product?.name}
                      className="h-24 w-24 rounded-lg object-cover"
                    />

                    <div className="flex-1">
                      <h3 className="font-semibold">{item.product?.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {item.product?.category}
                      </p>
                      <p className="mt-2 text-lg font-bold text-orange-500">
                        R$ {parseFloat(item.product?.price || "0").toFixed(2)}
                      </p>
                    </div>

                    <div className="flex flex-col items-end gap-4">
                      <button
                        onClick={() => handleRemove(item.id)}
                        className="text-muted-foreground hover:text-red-500"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>

                      <div className="flex items-center gap-2 border border-border rounded-lg">
                        <button
                          onClick={() =>
                            handleUpdateQuantity(item.id, item.quantity - 1)
                          }
                          className="px-3 py-1 hover:bg-muted"
                        >
                          −
                        </button>
                        <span className="w-6 text-center text-sm">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() =>
                            handleUpdateQuantity(item.id, item.quantity + 1)
                          }
                          className="px-3 py-1 hover:bg-muted"
                        >
                          +
                        </button>
                      </div>

                      <p className="font-semibold">
                        R${" "}
                        {(
                          parseFloat(item.product?.price || "0") *
                          item.quantity
                        ).toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Summary and Checkout */}
            <div className="lg:col-span-1">
              <div className="sticky top-24 rounded-xl border border-border bg-card p-6 animate-slideInRight">
                <h2 className="mb-6 text-xl font-bold">Resumo do Pedido</h2>

                <div className="mb-4 space-y-3 border-b border-border pb-4">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>R$ {subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Frete</span>
                    <span>
                      {shipping === 0 ? (
                        <span className="text-green-600">Grátis</span>
                      ) : (
                        `R$ ${shipping.toFixed(2)}`
                      )}
                    </span>
                  </div>
                </div>

                <div className="mb-6 flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span className="text-orange-500">R$ {total.toFixed(2)}</span>
                </div>

                {!showCheckout ? (
                  <Button
                    onClick={() => setShowCheckout(true)}
                    className="w-full btn-primary"
                  >
                    Ir para Checkout
                  </Button>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <label className="mb-2 block text-sm font-semibold">
                        Endereço
                      </label>
                      <Input
                        placeholder="Rua, número, complemento"
                        value={formData.shippingAddress}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            shippingAddress: e.target.value,
                          })
                        }
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-sm font-semibold">
                        Cidade
                      </label>
                      <Input
                        placeholder="Cidade"
                        value={formData.shippingCity}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            shippingCity: e.target.value,
                          })
                        }
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="mb-2 block text-sm font-semibold">
                          Estado
                        </label>
                        <Input
                          placeholder="SP"
                          value={formData.shippingState}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              shippingState: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <label className="mb-2 block text-sm font-semibold">
                          CEP
                        </label>
                        <Input
                          placeholder="00000-000"
                          value={formData.shippingZipCode}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              shippingZipCode: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>

                    <Button
                      onClick={handleCheckout}
                      disabled={createOrderMutation.isPending}
                      className="w-full btn-primary"
                    >
                      {createOrderMutation.isPending
                        ? "Processando..."
                        : "Finalizar Pedido"}
                    </Button>

                    <Button
                      onClick={() => setShowCheckout(false)}
                      className="w-full btn-ghost"
                    >
                      Voltar
                    </Button>
                  </div>
                )}

                <p className="mt-4 text-xs text-muted-foreground">
                  Frete grátis para pedidos acima de R$ 100
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

