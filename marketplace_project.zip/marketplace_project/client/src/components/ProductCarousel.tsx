import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Star } from "lucide-react";
import { Link } from "wouter";

interface CarouselProduct {
  id: number;
  name: string;
  image: string;
  price: string;
  originalPrice?: string | null;
  rating: string;
  reviewCount: number;
  category: string;
}

interface ProductCarouselProps {
  products: CarouselProduct[];
  autoPlayInterval?: number;
}

export default function ProductCarousel({
  products,
  autoPlayInterval = 5000,
}: ProductCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlay, setIsAutoPlay] = useState(true);

  useEffect(() => {
    if (!isAutoPlay || products.length === 0) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % products.length);
    }, autoPlayInterval);

    return () => clearInterval(interval);
  }, [isAutoPlay, products.length, autoPlayInterval]);

  const goToPrevious = () => {
    setCurrentIndex((prev) =>
      prev === 0 ? products.length - 1 : prev - 1
    );
    setIsAutoPlay(false);
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % products.length);
    setIsAutoPlay(false);
  };

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
    setIsAutoPlay(false);
  };

  if (!products || products.length === 0) {
    return null;
  }

  const currentProduct = products[currentIndex];
  const discount = currentProduct.originalPrice
    ? Math.round(
        ((parseFloat(currentProduct.originalPrice) -
          parseFloat(currentProduct.price)) /
          parseFloat(currentProduct.originalPrice)) *
          100
      )
    : 0;

  return (
    <div
      className="relative w-full overflow-hidden rounded-2xl bg-gradient-to-br from-orange-400 to-red-500"
      onMouseEnter={() => setIsAutoPlay(false)}
      onMouseLeave={() => setIsAutoPlay(true)}
    >
      {/* Carousel Container */}
      <div className="relative h-96 md:h-[500px] lg:h-[600px] w-full overflow-hidden">
        {/* Slides */}
        {products.map((product, index) => (
          <div
            key={product.id}
            className={`absolute inset-0 transition-opacity duration-500 ease-in-out ${
              index === currentIndex ? "opacity-100" : "opacity-0"
            }`}
          >
            <div className="grid h-full grid-cols-1 md:grid-cols-2 items-center">
              {/* Image Side */}
              <div className="relative h-full flex items-center justify-center bg-white/10 backdrop-blur-sm order-2 md:order-1">
                <img
                  src={product.image || "https://via.placeholder.com/400"}
                  alt={product.name}
                  className="h-full w-full object-cover"
                />
                {discount > 0 && (
                  <div className="absolute top-6 right-6 rounded-full bg-red-600 px-4 py-2 text-white font-bold text-lg shadow-lg">
                    -{discount}%
                  </div>
                )}
              </div>

              {/* Content Side */}
              <div className="flex flex-col justify-center px-6 md:px-12 py-8 text-white order-1 md:order-2">
                <span className="inline-block w-fit rounded-full bg-white/20 px-4 py-1 text-sm font-semibold mb-4 backdrop-blur-sm">
                  {product.category}
                </span>

                <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 line-clamp-3">
                  {product.name}
                </h2>

                {/* Rating */}
                <div className="flex items-center gap-3 mb-6">
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`h-5 w-5 ${
                          i < Math.round(parseFloat(product.rating || "0"))
                            ? "fill-yellow-300 text-yellow-300"
                            : "text-white/40"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm font-medium">
                    ({product.reviewCount} avaliações)
                  </span>
                </div>

                {/* Price */}
                <div className="mb-8">
                  <div className="flex items-baseline gap-3">
                    <span className="text-5xl font-bold">
                      R$ {parseFloat(product.price).toFixed(2)}
                    </span>
                    {product.originalPrice && (
                      <span className="text-xl line-through text-white/70">
                        R$ {parseFloat(product.originalPrice).toFixed(2)}
                      </span>
                    )}
                  </div>
                  {product.originalPrice && (
                    <p className="mt-2 text-sm text-white/90">
                      Economize R${" "}
                      {(
                        parseFloat(product.originalPrice) -
                        parseFloat(product.price)
                      ).toFixed(2)}
                    </p>
                  )}
                </div>

                {/* CTA Button */}
                <Link href={`/product/${product.id}`}>
                  <a className="inline-flex items-center justify-center rounded-lg bg-white text-orange-600 font-bold px-8 py-4 hover:bg-orange-50 transition-all duration-200 hover:scale-105 w-fit">
                    Ver Detalhes
                  </a>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={goToPrevious}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-10 rounded-full bg-white/20 p-3 text-white hover:bg-white/40 transition-all duration-200 backdrop-blur-sm hover:scale-110 md:left-6"
      >
        <ChevronLeft className="h-6 w-6" />
      </button>

      <button
        onClick={goToNext}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-10 rounded-full bg-white/20 p-3 text-white hover:bg-white/40 transition-all duration-200 backdrop-blur-sm hover:scale-110 md:right-6"
      >
        <ChevronRight className="h-6 w-6" />
      </button>

      {/* Indicators */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 flex gap-2">
        {products.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`h-3 rounded-full transition-all duration-300 ${
              index === currentIndex
                ? "w-8 bg-white"
                : "w-3 bg-white/50 hover:bg-white/75"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      {/* Gradient Overlay (bottom) */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-black/30 to-transparent pointer-events-none" />
    </div>
  );
}

