import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ PRODUCTS ============
  products: router({
    list: publicProcedure
      .input(
        z.object({
          limit: z.number().default(20),
          offset: z.number().default(0),
          category: z.string().optional(),
          search: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        return await db.getProducts(
          input.limit,
          input.offset,
          input.category,
          input.search
        );
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const product = await db.getProductById(input.id);
        if (!product) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return product;
      }),

    getByCategory: publicProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ input }) => {
        return await db.getProductsByCategory(input.category);
      }),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string(),
          description: z.string().optional(),
          price: z.string(),
          originalPrice: z.string().optional(),
          category: z.string(),
          subcategory: z.string().optional(),
          image: z.string().optional(),
          images: z.string().optional(),
          stock: z.number(),
          sku: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        await db.createProduct({
          ...input,
          seller: ctx.user.name || "Admin",
          sellerId: ctx.user.id,
          isActive: true,
        });
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          description: z.string().optional(),
          price: z.string().optional(),
          originalPrice: z.string().optional(),
          category: z.string().optional(),
          subcategory: z.string().optional(),
          image: z.string().optional(),
          images: z.string().optional(),
          stock: z.number().optional(),
          sku: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        const { id, ...updates } = input;
        await db.updateProduct(id, updates);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        await db.deleteProduct(input.id);
      }),
  }),

  // ============ CART ============
  cart: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const cartItems = await db.getUserCart(ctx.user.id);
      const itemsWithProducts = await Promise.all(
        cartItems.map(async (item) => {
          const product = await db.getProductById(item.productId);
          return { ...item, product };
        })
      );
      return itemsWithProducts;
    }),

    add: protectedProcedure
      .input(
        z.object({
          productId: z.number(),
          quantity: z.number().min(1),
        })
      )
      .mutation(async ({ input, ctx }) => {
        await db.addToCart(ctx.user.id, input.productId, input.quantity);
      }),

    remove: protectedProcedure
      .input(z.object({ cartItemId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await db.removeFromCart(input.cartItemId);
      }),

    updateQuantity: protectedProcedure
      .input(
        z.object({
          cartItemId: z.number(),
          quantity: z.number().min(0),
        })
      )
      .mutation(async ({ input, ctx }) => {
        await db.updateCartItemQuantity(input.cartItemId, input.quantity);
      }),

    clear: protectedProcedure.mutation(async ({ ctx }) => {
      await db.clearUserCart(ctx.user.id);
    }),
  }),

  // ============ ORDERS ============
  orders: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserOrders(ctx.user.id);
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const order = await db.getOrderById(input.id);
        if (!order) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        if (order.userId !== ctx.user.id && ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        const items = await db.getOrderItems(order.id);
        return { ...order, items };
      }),

    create: protectedProcedure
      .input(
        z.object({
          totalPrice: z.string(),
          paymentMethod: z.string().optional(),
          shippingAddress: z.string(),
          shippingCity: z.string(),
          shippingState: z.string(),
          shippingZipCode: z.string(),
          shippingCountry: z.string(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;

        const result = await db.createOrder({
          ...input,
          orderNumber,
          userId: ctx.user.id,
          status: "pending",
          paymentStatus: "pending",
        });

        // Clear cart after order
        await db.clearUserCart(ctx.user.id);

        return { orderNumber };
      }),

    updateStatus: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          status: z.enum([
            "pending",
            "confirmed",
            "processing",
            "shipped",
            "delivered",
            "cancelled",
          ]),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        await db.updateOrderStatus(input.id, input.status);
      }),
  }),

  // ============ REVIEWS ============
  reviews: router({
    getByProduct: publicProcedure
      .input(z.object({ productId: z.number() }))
      .query(async ({ input }) => {
        return await db.getProductReviews(input.productId);
      }),

    create: protectedProcedure
      .input(
        z.object({
          productId: z.number(),
          orderId: z.number().optional(),
          rating: z.number().min(1).max(5),
          title: z.string().optional(),
          comment: z.string().optional(),
          images: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        await db.createReview({
          ...input,
          userId: ctx.user.id,
          isVerifiedPurchase: !!input.orderId,
        });
      }),
  }),

  // ============ MESSAGES ============
  messages: router({
    getConversation: protectedProcedure
      .input(z.object({ conversationId: z.string() }))
      .query(async ({ input, ctx }) => {
        const messages = await db.getConversation(input.conversationId);
        // Mark as read
        await db.markMessagesAsRead(input.conversationId, ctx.user.id);
        return messages;
      }),

    getUserConversations: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserConversations(ctx.user.id);
    }),

    send: protectedProcedure
      .input(
        z.object({
          conversationId: z.string(),
          recipientId: z.number(),
          productId: z.number().optional(),
          orderId: z.number().optional(),
          message: z.string(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        await db.sendMessage({
          ...input,
          senderId: ctx.user.id,
          isRead: false,
        });
      }),
  }),

  // ============ SHIPMENTS ============
  shipments: router({
    getByOrder: publicProcedure
      .input(z.object({ orderId: z.number() }))
      .query(async ({ input }) => {
        return await db.getShipmentByOrderId(input.orderId);
      }),

    create: protectedProcedure
      .input(
        z.object({
          orderId: z.number(),
          trackingNumber: z.string().optional(),
          carrier: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        await db.createShipment({
          ...input,
          status: "pending",
        });
      }),

    updateStatus: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          status: z.enum([
            "pending",
            "picked_up",
            "in_transit",
            "out_for_delivery",
            "delivered",
            "failed",
          ]),
          lastUpdate: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        await db.updateShipmentStatus(input.id, input.status, input.lastUpdate);
      }),
  }),
});

export type AppRouter = typeof appRouter;

